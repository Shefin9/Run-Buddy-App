package com.example.trial;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.MediaRouteButton;
import android.app.Notification;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class SignIn extends AppCompatActivity{
    Button signUpBtn;
    Button signInBtn;
    TextInputLayout phoneNo, password;
    TextView forgotTextLink;
//    FirebaseAuth fAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        signInBtn=findViewById(R.id.signIn);
        signUpBtn = findViewById(R.id.signUp);
        phoneNo=findViewById(R.id.phoneNo_signIn);
        password=findViewById(R.id.password_signIn);
        forgotTextLink=findViewById(R.id.forgotPassword);
//        fAuth=FirebaseAuth.getInstance();


    }

    private Boolean validatePhoneNo() {
        String val = phoneNo.getEditText().getText().toString();

        if (val.isEmpty()) {
            phoneNo.setError("Field cannot be empty");
            return false;
        }
        else if (val.length() != 10){
            phoneNo.setError("Invalid Mobile No.");
            return false;
        }
        else {
            phoneNo.setError(null);
            phoneNo.setErrorEnabled(false);
            return true;
        }
    }

    private Boolean validatePassword() {
        String val = password.getEditText().getText().toString();
        if (val.isEmpty()) {
            password.setError("Field cannot be empty");
            return false;
        } else {
            password.setError(null);
            password.setErrorEnabled(false);
            return true;
        }
    }

    public void loginUser(View view) {
        //Validate Login Info
        if (!validatePhoneNo() | !validatePassword())
            return;
        else {
            isUser();
        }
    }

    private void isUser() {
        final String userEnteredPhoneNo = phoneNo.getEditText().getText().toString().trim();
        final String userEnteredPassword = password.getEditText().getText().toString().trim();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("users");
        Query checkUser = reference.orderByChild("phoneNo").equalTo(userEnteredPhoneNo);
        checkUser.addListenerForSingleValueEvent(new ValueEventListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                if (dataSnapshot.exists()) {
                    phoneNo.setError(null);
                    phoneNo.setErrorEnabled(false);
                    String passwordFromDB = dataSnapshot.child(userEnteredPhoneNo).child("password").getValue(String.class);
                    if (passwordFromDB.equals(userEnteredPassword)) {
                        phoneNo.setError(null);
                        phoneNo.setErrorEnabled(false);
                        String nameFromDB = dataSnapshot.child(userEnteredPhoneNo).child("name").getValue(String.class);
                        String phoneNoFromDB = dataSnapshot.child(userEnteredPhoneNo).child("phoneNo").getValue(String.class);
                        String emailFromDB = dataSnapshot.child(userEnteredPhoneNo).child("email").getValue(String.class);
                        Intent intent = new Intent(getApplicationContext(), ProfileActivity.class);
                        intent.putExtra("name", nameFromDB);
                        intent.putExtra("email", emailFromDB);
                        intent.putExtra("phoneNo", phoneNoFromDB);
                        intent.putExtra("password", passwordFromDB);
                        startActivity(intent);
                    } else {

                        password.setError("Wrong Password");
                        password.requestFocus();
                    }
                } else {
                    phoneNo.setError("No such User exist");
                    phoneNo.requestFocus();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    public void registerUser(View view) {
        Intent intent = new Intent(SignIn.this, SignUp.class);
        startActivity(intent);
    }
    public void forgotpass(View view){
        Intent i = new Intent(SignIn.this, ResetPassword.class);
        startActivity(i);


    }
}