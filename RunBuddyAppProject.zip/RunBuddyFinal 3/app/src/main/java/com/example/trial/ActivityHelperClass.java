package com.example.trial;

import java.util.Calendar;
import java.util.Date;

public class ActivityHelperClass {

    String distance, time, speed, ctime;

    public ActivityHelperClass() {

    }

    public ActivityHelperClass(String distance, String time, String speed, String ctime) {
        this.distance = distance;
        this.time = time;
        this.speed = speed;
        this.ctime = ctime;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getSpeed() {
        return speed;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }

    public String getCurrentTime() {
        return ctime;
    }

    public void setCurrentTime(String ctime) {
        this.ctime = ctime;
    }

}
