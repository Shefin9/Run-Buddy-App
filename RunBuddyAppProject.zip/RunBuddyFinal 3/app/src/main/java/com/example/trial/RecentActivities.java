package com.example.trial;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class RecentActivities extends AppCompatActivity {

    String ph,p,n,e;
    FirebaseDatabase rootNode;
    DatabaseReference reference, ref;
    TextView t;
    String d = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recentactivities);

        t = findViewById(R.id.recent);

        Intent intent = getIntent();
        Bundle b = intent.getExtras();
        ph = (String) b.get("phoneNo");
        p = (String) b.get("password");
        n = (String) b.get("name");
        e = (String) b.get("email");

        rootNode = FirebaseDatabase.getInstance();
        reference = rootNode.getReference("users");
        ref = reference.child(ph).child("activity");



        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot1 : snapshot.getChildren()) {
                    String currentTime = String.valueOf(dataSnapshot1.child("currentTime").getValue());
                    String distance = String.valueOf(dataSnapshot1.child("distance").getValue());
                    String time = String.valueOf(dataSnapshot1.child("time").getValue());
                    String speed = String.valueOf(dataSnapshot1.child("speed").getValue());

                    d = d + currentTime + "\n" + distance + "\n" + time + "\n" + speed + "\n\n";

                }

                if (d.equals("")){
                    t.setText("No activities to show");
                }
                else {
                    t.setText(d);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
    public void gotoProfile(View view){
        Intent i = new Intent(RecentActivities.this, ProfileActivity.class);
        i.putExtra("phoneNo", ph);
        i.putExtra("name", n);
        i.putExtra("email", e);
        i.putExtra("password", p);

        startActivity(i);
    }

}