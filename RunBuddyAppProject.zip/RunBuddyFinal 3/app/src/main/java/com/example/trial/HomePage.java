package com.example.trial;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HomePage extends AppCompatActivity {
    String p,n,e,pa;
    TextView t,d;
    String[] tt;
    String[] dd;

    List<String> tt1 = new ArrayList<String>();
    List<String> dd1 = new ArrayList<String>();

    int min=0,sec=0, km=0, m=0;
    double total, total2;
    FirebaseDatabase rootNode;
    DatabaseReference reference, ref, ref1;
    private static DecimalFormat df2 = new DecimalFormat("#.##");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_new);
        Intent intent = getIntent();
        Bundle b = intent.getExtras();
        p = (String) b.get("phoneNo");
        n = (String) b.get("name");
        e = (String) b.get("email");
        pa = (String) b.get("password");
        t=findViewById(R.id.ttime);
        d=findViewById(R.id.tdis);


        rootNode = FirebaseDatabase.getInstance();
        reference = rootNode.getReference("users");
        ref1 = reference.child(p);
        ref = ref1.child("activity");



        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()){
                    t.setText("00");
                    d.setText("00");
                    return;
                }

                else{
                    ref.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            for (DataSnapshot dataSnapshot1 : snapshot.getChildren()) {
                                String distance = String.valueOf(dataSnapshot1.child("distance").getValue());
                                String time = String.valueOf(dataSnapshot1.child("time").getValue());
                                int len = distance.length();
                                distance = distance.substring(0, len-3);
                                tt = time.split(":");
                                dd = distance.split("\\.");

                                tt1.add(tt[0]);
                                tt1.add(tt[1]);

                                dd1.add(dd[0]);
                                dd1.add(dd[1]);

                            }

                            int l = tt1.size();
                            for (int f=0; f<l-1; f=f+2){
                                min=min+Integer.parseInt(tt1.get(f));
                                sec=sec+Integer.parseInt(tt1.get(f+1));
                            }

                            total = (double)(sec + (min*60))/60;
                            double scale = Math.pow(10, 2);
                            total = Math.round(total * scale) / scale;

                            if (total==0.00){
                                t.setText("00");
                            }
                            else {
                                t.setText(Double.toString(total));
                            }

                            int ll = dd1.size();
                            for (int g=0; g<ll-1; g=g+2){
                                km=km+Integer.parseInt(dd1.get(g));
                                m=m+Integer.parseInt(dd1.get(g+1));
                            }

                            total2 = (double)(m + (km*1000))/1000;
                            double sca = Math.pow(10, 2);
                            total2 = Math.round(total2 * sca) / sca;

                            if (total2==0.00){
                                d.setText("00");
                            }
                            else {
                                d.setText(Double.toString(total2));
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
    public void newActivity(View view){
        Intent i = new Intent(HomePage.this, NewActivity.class);
        i.putExtra("phoneNo", p);
        i.putExtra("name", n);
        i.putExtra("email", e);
        i.putExtra("password", pa);
        startActivity(i);
    }

    public void gotoProfile(View view){
        Intent i = new Intent(HomePage.this, ProfileActivity.class);
        i.putExtra("phoneNo", p);
        i.putExtra("name", n);
        i.putExtra("email", e);
        i.putExtra("password", pa);

        startActivity(i);
    }

    public void viewAll(View view){
        Intent i = new Intent(HomePage.this, RecentActivities.class);
        i.putExtra("phoneNo", p);
        i.putExtra("name", n);
        i.putExtra("email", e);
        i.putExtra("password", pa);
        startActivity(i);
    }
}
